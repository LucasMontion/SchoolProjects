const express = require("express"); //eslint-disable-line
const knexModule = require("knex"); //eslint-disable-line
const templateListe = require("./template.js").templateListe;

const knex = knexModule({
	client: "mssql",
	connection: {
		host: "sv55.cmaisonneuve.qc.ca",
		user: "3D1",
		password: "Projet3689",
		database: "college",
		options: {
			enableArithAbort: false,
		},
	},
	pool: { min: 0, max: 7 },
});
const app = express();
app.use(express.static("public"));

// 1 - Les compétences d'un programme ordonnées par code (code, énoncé)
// requête: competences-programme?id={valeur}
async function competencesDunProgramme(idProgramme) {
	const resultat = {
		donnes: [],
		groupes: [],
	};

	resultat.donnes = await knex('competences')
		.select('idProgramme', 'code', 'enonce')
		.where({
			idProgramme,
		})
		.orderBy('code');

	resultat.groupes.push({ format: '1 - Compétences du programme %', valeurs: ['idProgramme'] });
	resultat.groupes.push({ format: '% %', valeurs: ['code', 'enonce'] });

	return resultat
}





// 2 - Les compétences d'un programme avec leurs éléments de compétence, ordonnées par code et par no (code, énoncé, no, element)
// requête: cours-competences-profil?id={valeur}
async function competencesElementsDunProgramme(idProgramme) {
	const resultat = {
		donnes: [],
		groupes: [],
	};

	resultat.donnes = await knex("Competences")
		.select("Code", "Enonce","ElementCompetences.No", "ElementCompetences.Element")
		.join("ElementCompetences", "ElementCompetences.IdCompetence", "=", "Competences.Id")
		.where({idProgramme})
		.orderBy("Code")
		.orderBy("ElementCompetences.No");

	resultat.groupes.push({ format: '2 - Compétences et éléments du programme %', valeurs: ['420'] });
	resultat.groupes.push({ format: '% %', valeurs: ['Code', 'Enonce'] });
	resultat.groupes.push({ format: '% %', valeurs: ['No', 'Element'] });
	return resultat

}



// 3 - Cours et compétences du profil Infrastructure réseaux
// Titre: Compétences du profil {nom du profil}
async function coursCompetencesProfil(idProfil) {
	const resultat = {
		donnes: [],
		groupes: [],
	};
	resultat.donnes = await knex("Cours")
		.select("Profils.Nom", "CoursProfils.Session", "Cours.Sigle", "Cours.Titre", "Cours.HeuresTotales", "Competences.Code", "Competences.Enonce", "ElementCompetences.Element")
		.join("Competences", "Competences.IdChampCompetences", "=", "Cours.IdChampCompetences")
		.join("ElementCompetences", "ElementCompetences.IdCompetence", "=", "Competences.Id")
		.join("Profils", "Profils.IdProgramme", "=", "Competences.IdProgramme")
		.join("CoursProfils", "CoursProfils.IdCours", "=", "Cours.Id")
		.where("idProfil", idProfil)
		.groupBy("Profils.Nom", "CoursProfils.Session", "Cours.Sigle", "Cours.Titre", "Cours.HeuresTotales", "Competences.Code", "Competences.Enonce", "ElementCompetences.Element")
		.orderBy("CoursProfils.Session")
		.orderBy("Cours.Sigle")

	resultat.groupes.push({ format: '3 - Cours et comptences du profil %', valeurs: ['Nom'] });
	resultat.groupes.push({ format: 'Session %', valeurs: ['Session'] });
	resultat.groupes.push({ format: '% % % heures.', valeurs: ['Sigle', 'Titre', 'HeuresTotales'] });
	resultat.groupes.push({ format: '% %', valeurs: ['Code', 'Element'] });
	return resultat
}

// 4 - Compétences et cours du profil Développement d'application
// requête: competences-cours profil?id={valeur}
async function competencesCoursProfil(idProfil) {
	const resultat = {
		donnes: [],
		groupes: [],
	};
	resultat.donnes = await knex("Competences")
		.select("Profils.Nom", "Competences.Code","Competences.Enonce","Cours.Sigle", "Cours.Titre" )
		.join("CompetenceCours","CompetenceCours.IdCompetence","=","Competences.Id")
		.join("Cours", "Cours.id","=","CompetenceCours.IdCours")
		.join("ProfilsCompetences", "ProfilsCompetences.IdCompetence","=","Competences.Id")
		.join("Profils", "ProfilsCompetences.IdProfil","=","Profils.Id")
		.where("Profils.id",idProfil)
		.orderBy("Competences.Code");

	resultat.groupes.push({ format: '4 - Compétences et cours du profil %', valeurs: ['Nom'] });
	resultat.groupes.push({ format: '% %', valeurs: ["Code","Enonce"] });
	resultat.groupes.push({ format: '% %', valeurs: ["Sigle", "Titre"] });
	return resultat
}

// 5 - Description des cours du profil Développement d'application
// requête: cours-profil?id={valeur}
async function descriptionCoursProfil(idProfil) {
	const resultat = {
		donnes: [],
		groupes: [],
	};
	resultat.donnes = await knex("Cours")
		.select("Profils.Nom", "CoursProfils.Session","Cours.Sigle", "Cours.Titre", "Cours.HeuresTheoriques", 'Cours.HeuresPratiques', 'Cours.HeuresPersonnelles', "Cours.Description" )
		.join("CoursProfils", "CoursProfils.IdCours", "=", "Cours.Id")
		.join("Profils", "Profils.Id", "=", "CoursProfils.IdProfil")
		.where("Profils.Id", idProfil)
		.orderBy("CoursProfils.Session")
		.orderBy("Cours.Sigle");

	resultat.groupes.push({ format: '5 - Description des cours du profil %', valeurs: ['Nom'] });
	resultat.groupes.push({ format: 'Session %', valeurs: ["Session"] });
	resultat.groupes.push({ format: '% % % %  %', valeurs: ["Sigle","Titre", "HeuresTheoriques", "HeuresPratiques", "HeuresPersonnelles"] });
	resultat.groupes.push({ format: '%', valeurs: ["Description"] });
	return resultat
}





app.get("/", async (requete, reponse) => {
	try {
		reponse.sendFile(__dirname+"/index.html"); //eslint-disable-line
	} catch (err) {
		console.log(err);
		return null;
	}
});



//QUESTION 1
app.get("/competences-programme/:id", async (requete, reponse) => {
	try {
		const id = requete.params.id
		const groupes = (await competencesDunProgramme(id)).groupes
		const  donnes= (await competencesDunProgramme(id)).donnes

		reponse.send(templateListe({groupes, donnes}));

		return null;
	} catch (err) {
		console.log(err);
		return null;
	}
});

//QUESTION 2
app.get("/elements-competences-programme/:id", async (requete, reponse) => {
	try {
		const id = requete.params.id
		const groupes = (await competencesElementsDunProgramme(id)).groupes
		const  donnes= (await competencesElementsDunProgramme(id)).donnes

		reponse.send(templateListe({groupes, donnes}))

	} catch (err) {
		console.log(err);
		return null;
	}
});

//QUESTION 3
app.get("/cours-competences-profil/:id", async (requete, reponse) => {
	try {
		const id = requete.params.id
		const groupes = (await coursCompetencesProfil(id)).groupes
		const  donnes= (await coursCompetencesProfil(id)).donnes

		reponse.send(templateListe({groupes, donnes}));
	} catch (err) {
		console.log(err);
		return null;
	}
});

//QUESTION 4
app.get("/competences-cours-profil/:id", async (requete, reponse) => {
	try {
		const id = requete.params.id
		const groupes = (await competencesCoursProfil(id)).groupes
		const  donnes= (await competencesCoursProfil(id)).donnes

		reponse.send(templateListe({groupes, donnes}));
	} catch (err) {
		console.log(err);
		return null;
	}
});

//QUESTION 5
app.get("/cours-profil/:id", async (requete, reponse) => {
	try {
		const id = requete.params.id
		const groupes = (await descriptionCoursProfil(id)).groupes
		const  donnes= (await descriptionCoursProfil(id)).donnes

		reponse.send(templateListe({groupes, donnes}));
	} catch (err) {
		console.log(err);
		return null;
	}
});



app.listen(5000, () => {
	console.log(`Serveur en cours d'exécution: http://localhost:5000/`);
	console.log(' QUESTION 1 : http://localhost:5000/competences-programme/420')
	console.log(' QUESTION 2 : http://localhost:5000/elements-competences-programme/420')
	console.log(' QUESTION 3 : http://localhost:5000/cours-competences-profil/1')
	console.log(' QUESTION 4 : http://localhost:5000/competences-cours-profil/2')
	console.log(' QUESTION 5 : http://localhost:5000/cours-profil/2')

});
