const formaterLigne = require("./formaterLigne.js").formaterLigne;

const templateListe = ({ groupes, donnes }) => {
    let elements = '';

    const entetes = [];
    entetes[groupes.length - 1] = '';
    let idxLigne = 0;
    let idxEnteteAAfficher;
    while (idxLigne < donnes.length) {
        // Construit les entêtes au besoin
        idxEnteteAAfficher = groupes.length - 1;//detail
        for (let i = groupes.length - 2; i >= 0; i -= 1) {
            const nouvelleEntete = formaterLigne(donnes[idxLigne], groupes[i]);
            if (nouvelleEntete !== entetes[i]) {
                idxEnteteAAfficher = i;
                entetes[i] = nouvelleEntete;
            }
        }
        backgroundColor = ["has-background-primary", "has-background-success", "has-background-link"];
        padding = ["ml-1","ml-2","ml-2"]
        textColor = ["has-text-black","has-text-black", "has-text-white"]
        for (let i = idxEnteteAAfficher; i < groupes.length - 1; i += 1) {
            // Affiche l'entête actualisée
            elements += `
                <h${i + 1} class="
                box 
                ${backgroundColor[i]} 
                ${textColor[i]} 
                has-text-weight-medium 
                ${padding[i]} 
                p-3 
                mt-1 
                mb-1
                ">
                ${entetes[i]}
                </h${i + 1}>
                        `;
        }

        // Affiche le détail
        const detail = formaterLigne(donnes[idxLigne], groupes[groupes.length - 1]);

        elements += `<p class="box 
        has-background-info 
        p-2
        mb-1 
        ml-4 
        has-text-white 
        is-family-primary
        has-text-weight-semibold
        ">${detail}</p>`;
        idxLigne += 1;
    }

    const html = `<!DOCTYPE html>
  <html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mandat 4</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.3/css/bulma.min.css">
  </head>
  <body>

    <section class="hero">
    <nav class="navbar is-link" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
              <a class="navbar-item">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgOBg4IBwgPBxMHEAoIBw8OCA8ICRIKFhIiFiARHx8YHSgsGCYlGxMTIT0hMTowOi4uGB8zOD8sNygtOjcBCgoKDg0OFRAQDisZFRkrKysrKzcrLS03Ny0rNysrNysrLSsrLSsrKysrKzcrLS0rKysrNysrKystLSsrLTcrK//AABEIALQAtAMBIgACEQEDEQH/xAAbAAEAAwADAQAAAAAAAAAAAAAABQYHAwQIAf/EADAQAQABAwIDBwIFBQAAAAAAAAADAQIEBQYRErEhJDE0UWGCQcIiM1JikRQyoqPB/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAMEBQIB/8QAIhEBAAIBAwQDAQAAAAAAAAAAAAECAwQRYTEyQUISFFEh/9oADAMBAAIRAxEAPwBsTefHk0vWJe38MeDNdd4+kd1elWiPOjRth7z48mlavL+mPBmuu8fSO6vSrUz4ParIrbxLRQFJIAAAAAAAAAAAAAAAAOHKyYYse6fIkpFbFTmkuqZWTDFj3ZGRJSG2KnNJdX6M03Frs2ZkcKcYYoq93j5v8q+/TrZ0+nnJPCDNmikcu7qO8tTuy7rsCv8ATx07Ira20uvrT1r2V7RWhp/VxfjP+xk/VdAcr7R9ibz48ml6xL2/l4M113j6R3V6VaI86NG2HvPjyaVq8v6Y8Ga67x9I7q9KqWfB7VSVt4looCkkAAAAAAAAAAAAHDlZMMWPdPkSUhtipzSXVMrJhix7p8iSkNsVOaS6v0ZpuLXZszI4U4wxRV7vZ91ffp1safTzknhBmzRSOTcOvTZs/CnGKKGvd7Obx/fd79P5rWHBt0pFI2hlWtNp3kAdOVdAVGsAA0fYm8+PJpesS9v4Y8Ga67x9I7q9KtEedGjbD3nx5dK1eXt/LwZrrvH0jur0qpZ8HtVJW3iWigKSQAAAAAAAAcOVkwxY90+RJSG2KnNJdUysmGLHuyMiSkNsVOaS6v0ZpuLXZszI4U4wxRV7vZ91ffp1s6fTzknhBmzRSOTcWvTZuRwpxhiir3ez1/fd79P5rWHBtUpFI2qyrWm07yAOnIACugKjWAAAAaPsTefHk0vWJe38MeHNdd4+kd1elWiPOjRti70pwt0vWZf7eWPBnuu/13V6VUs+D2qkrbxLRQFJIAAAAOHKyYYse6fIkpDbFTmkur9DLyYYce7IyJKQ2xU5pLqs03Frs2ZkcO2GKKvd7Pur79OtjT6eck8IM2aKRy+7i16bNn4U4wxQ17vZ6/vr79P5rWGBt0pFI+NWVa02neQB05AAAAV0BUawAAAAADQ9ibz5eTStXl7Py8Ga67w9LLq9KtIedGibE3nw5NK1iXs/LwZrrvD0jur0qpZ8HtVJW3iWjgKSQcOXkww492RkyUitipzSXVMvJhhx7sjIkpDbFTmkuqzPcOuzZuR9YY4q93s+6vv0WNPp5yTwgzZopHL7uLXZszI4U4wxRV7vZ91ffp/PGHBt0pFI2qyrWm07yAOnIAAAAACugKjWAAAAAAAAaHsTeXLy6Xq8vZ+GPBmuu8PSO6vSrQsvJhhx7p8mSkNsVOaS6rz0ssOqZ0+nxY+XkXTW4nNZDSv/AH9Xp2q86WLX/jy+X4V3Su4tdmzMjh2wxRV7vZ6/vr79OsODRpSKR8YZtrTad5AHTgAAAAAAABXQFRrAAAAAAAACY03y3yuQ6Y03y3yuSY+qDUdjtAJ1AAAAAAAAAABXQFRrAAAAAAAACY03y3yuQ6Y03y3yuSY+qDUdjtAJ1AAAAAAAAAABXQFRrAAAAAAAACY03y3yuQ6Y03y3yuSY+qDUdjtAJ1AAAAAAAAAABXQFRrAAAAAAAACY03y3yuQ6Y03y3yuSY+qDUdjtAJ1AAAAAAAAAABXQFRrAAAAAAAACY03y3yuQ6Y03y3yuSY+qDUdjtAJ1AAAAAAAAAABXQFRrAAAAAAAACY03y3yuBJj6oNR2O0AnUAAAAAAAAAAH/9k=" >
              </a>

              <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
                <span aria-hidden="true"></span>
              </a>
            </div>

                <div id="navbarBasicExample" class="navbar-menu">
                    <div class="navbar-start">
                    <a class="navbar-item has-text-black" href="http://localhost:5000">
                        Accueil
                    </a>
                    <a class="navbar-item has-text-black" href="http://localhost:5000/competences-programme/420">
                    Page 1
                  </a>
                  <a class="navbar-item has-text-black" href="http://localhost:5000/elements-competences-programme/420">
                    Page 2
                  </a>
                  <a class="navbar-item has-text-black" href="http://localhost:5000/cours-competences-profil/1">
                    Page 3
                  </a>
                  <a class="navbar-item has-text-black" href="http://localhost:5000/competences-cours-profil/2">
                    Page 4
                  </a>
                  <a class="navbar-item has-text-black" href="http://localhost:5000/cours-profil/2">
                    Page 5
                  </a>
                  <a class="navbar-item has-text-black" href="http://localhost:5000/charge-travail-profil-programme/420">
                    Page 6
                  </a>
                  <a class="navbar-item has-text-black" href="http://localhost:5000">
                    Page 7
                  </a>
                  
                </div>
            </div>
        </nav>
        </div>
        ${elements}
                        
    </section>
    
  

  </body>
  </html>`;

    return html;
}

module.exports = {
    templateListe
}
