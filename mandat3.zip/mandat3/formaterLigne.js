function formaterLigne(ligne, { format, valeurs }) {
    let resultat = format;
    for (let idxCol = 0; idxCol < valeurs.length; idxCol += 1) {
        resultat = resultat.replace('%', ligne[valeurs[idxCol]]);
    }
    return resultat
}

module.exports = {
    formaterLigne
}
