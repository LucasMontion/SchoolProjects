import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Prisonnier implements Observable{
	String name;
	Position position;
	Prison prison;
	
	
	
	private List<Observer> observers;
	
	
	
	public Prisonnier(String name, Position position, Prison prison) {
		this.observers = new ArrayList<Observer>();
		this.name = name;
		this.position = position;
		this.prison = prison;
	}

	public String getName() {
		return this.name;
	}
	
	public Position getPosition() {
		return this.position;
	}

	public void setPosition(Position position) throws IOException {
		this.position = position;
		if((position.x > (prison.SG.x + prison.longueur) || position.x < (prison.SG.x) ) || (position.y > (prison.SG.y) || position.y < (prison.SG.y - prison.largeur))) {
			NotifyAllObservers();
			System.out.println("Le prisonnier "+this.name+" s'est �chap�. Sa position: "+position.x +" "+ position.y);
		}else {
			System.out.println("Le prisonnier "+this.name+" est � l'int�rieur de la prison");
		}
		
	}
	
   

	@Override
	public void NotifyAllObservers() throws IOException {
		// TODO Auto-generated method stub
		for (Observer o : observers) {
			
	        o.update(this);
	    }
	}

	@Override
	public void Attach(Observer o) {
		// TODO Auto-generated method stub
		this.observers.add(o);
		
		
	}

	@Override
	public void Remove(Observer o) {
		// TODO Auto-generated method stub
		for(int indice=0;indice< this.observers.size();indice++)
			if(this.observers.get(indice).equals(o))
					this.observers.remove(o);
		
	}
}
