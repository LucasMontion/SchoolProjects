import java.io.IOException;

public interface Observer {
	
	void update(Prisonnier P) throws IOException;
}
