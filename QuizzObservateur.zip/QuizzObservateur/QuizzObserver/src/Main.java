import java.io.IOException;  // Import the IOException class to handle errors


public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Prisonnier p1 = new Prisonnier("Lucas", new Position(5,4), new Prison(6,3, new Position(2,4)));
		
		p1.Attach(new Gendarme());
		p1.Attach(new Police());
		p1.Attach(new Fichier());
		
		p1.setPosition(new Position(5,3));
		p1.setPosition(new Position(11,1));
		
		
	}
}
