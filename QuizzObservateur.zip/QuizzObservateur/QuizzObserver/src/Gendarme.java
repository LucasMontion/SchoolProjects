
public class Gendarme implements Observer{	
	
	
	@Override
	public void update(Prisonnier P) {
		// TODO Auto-generated method stub

		System.out.println("Prisonnier:"+ P.name);
		System.out.println("Coords: x "+P.position.x+", y "+P.position.y);
		
	}

}
