import java.io.FileWriter;
import java.io.IOException;


public class Fichier  implements Observer{

	@Override
	public void update(Prisonnier p) throws IOException {
		
		String message="Prisonnier:"+p.name+", Position:"+p.position.x+","+p.position.y;
		FileWriter Log = new FileWriter("prisonnier"+p.name+".txt", true);
		Log.write("\n"+message+"\n");  
		Log.close();
      

	}

}
