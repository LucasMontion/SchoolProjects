import java.io.IOException;

public interface Observable {
	
	void NotifyAllObservers() throws IOException;
	void Attach(Observer o);
	void Remove(Observer o);
}
