
public class Position {
	float x,y;

	public Position(float x, float y) {
		this.x = x;
		this.y = y;
	}

	
}
