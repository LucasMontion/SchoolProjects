
public class Prison{
	
	float longueur,largeur;
	Position SG;
	
	public Prison(float longueur, float largeur, Position sG) {
		
		this.longueur = longueur;
		this.largeur = largeur;
		SG = sG;
	}
	

}
